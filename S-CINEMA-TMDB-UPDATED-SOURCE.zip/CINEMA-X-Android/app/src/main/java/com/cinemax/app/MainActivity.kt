package com.cinemax.app

import android.app.Activity
import android.media.AudioManager
import android.view.MotionEvent
import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AccelerateDecelerateInterpolator
import android.animation.ObjectAnimator
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private data class CinemaItem(
    val title: String,
    val category: String,
    val year: String,
    val description: String,
    val streamUrl: String,
    val isDemo: Boolean = true
)

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 6, 9)
    private val panel = Color.rgb(16, 18, 22)
    private val silver = Color.rgb(235, 237, 242)
    private val muted = Color.rgb(151, 158, 170)
    private val accent = Color.rgb(220, 224, 232)
    private var player: ExoPlayer? = null
    private var currentCategory = "الكل"
    private var searchTerm = ""
    private val prefs by lazy { getSharedPreferences("scinema_state", Context.MODE_PRIVATE) }
    private var currentItem: CinemaItem? = null
    private var loadingOverlay: FrameLayout? = null
    private lateinit var contentRoot: LinearLayout
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureStartValue = 0f
    private var gestureSide = 0
    private var gestureHud: TextView? = null
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    // فيديو اختبار مفتوح بترخيص Creative Commons؛ ليس فيلماً تجارياً.
    private val demoUrl =
        "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"

    private val items = mutableListOf(
        CinemaItem("Big Buck Bunny", "أفلام", "2008", "فيديو تجريبي لاختبار المشغّل", demoUrl),
        CinemaItem("تجربة المشغّل", "مسلسلات", "Demo", "مسلسل تجريبي — أضف الحلقات المرخّصة", demoUrl),
        CinemaItem("أحلى نصيب", "مسلسلات", "2026", "ابحث عن توفر الحلقات ومصدر المشاهدة المرخّص", ""),
        CinemaItem("ليالي المدينة", "مسلسلات", "2026", "دراما • حلقة جديدة يومياً", ""),
        CinemaItem("قريباً", "أفلام", "—", "أضف محتواك المرخّص إلى الكتالوج", "")
    )

    // TMDB API key supplied by the app owner. For a public release, move API calls behind a backend.
    private val tmdbApiKey = "b396f6bc92a5ccf2775970f564d4dfce"
    private var moviePage = 1
    private var tvPage = 1
    private var searchRequestId = 0
    private val networkHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        loadPopularCatalog(reset = true)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int = 16, strokeColor: Int? = null): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }
    }

    private fun text(
        value: String,
        size: Float,
        color: Int = silver,
        bold: Boolean = false
    ): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun baseColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
    }

    private fun addGap(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun styleButton(button: Button, primary: Boolean = false) {
        button.setTextColor(if (primary) Color.rgb(8, 9, 12) else silver)
        button.textSize = 14f
        button.isAllCaps = false
        button.background = if (primary) {
            GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(248, 249, 252), Color.rgb(183, 190, 202))).apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.rgb(255, 255, 255))
            }
        } else {
            GradientDrawable().apply {
                setColor(Color.argb(170, 28, 31, 38))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.argb(145, 135, 145, 160))
            }
        }
        button.elevation = dp(2).toFloat()
        button.setPadding(dp(16), dp(10), dp(16), dp(10))
    }

    private fun showHome() {
        releasePlayer()
        val root = baseColumn()
        val scroll = ScrollView(this)
        val page = baseColumn()
        page.setPadding(dp(18), dp(18), dp(18), dp(24))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = text("S CINEMA", 25f, silver, true)
        val x = text("", 25f, accent, true)
        top.addView(logo)
        top.addView(x)
        val spacer = View(this)
        top.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        val settings = Button(this).apply { text = "⚙" }; styleButton(settings)
        settings.setOnClickListener { showSettings() }
        top.addView(settings)
        val account = Button(this).apply { text = "حسابي" }; styleButton(account)
        account.setOnClickListener { showProfile() }
        top.addView(account)
        val status = text("S", 22f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = rounded(Color.BLACK, 12, Color.WHITE)
        }
        top.addView(status)
        page.addView(top)
        addGap(page, 8)
        page.addView(text("عالمك السينمائي بمكان واحد", 14f, muted))
        addGap(page, 20)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(52,58,69), Color.rgb(20,23,29), Color.rgb(7,8,11))
            ).apply { cornerRadius = dp(22).toFloat() }
        }
        hero.addView(text("ليلة سينمائية", 23f, Color.WHITE, true))
        addGap(hero, 6)
        hero.addView(text("اكتشف المحتوى وشغّل الفيديو داخل التطبيق", 13f, silver))
        addGap(hero, 14)
        val heroButton = Button(this).apply { text = "جرّب المشغّل الآن" }
        styleButton(heroButton, true)
        heroButton.setOnClickListener { playItem(items[0]) }
        hero.addView(heroButton, LinearLayout.LayoutParams(-2, dp(48)))
        page.addView(hero)
        addGap(page, 20)

        val search = EditText(this).apply {
            hint = "ابحث عن فيلم أو مسلسل..."
            setHintTextColor(muted)
            setTextColor(silver)
            textSize = 14f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(panel, 14, Color.rgb(52,52,58))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    searchTerm = s?.toString()?.trim().orEmpty()
                    renderCatalog(catalogContainer)
                    scheduleRemoteSearch(searchTerm)
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        page.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        addGap(page, 14)

        val categories = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        listOf("الكل", "أفلام", "مسلسلات").forEach { category ->
            val b = Button(this).apply { text = category }
            styleButton(b, currentCategory == category)
            b.setOnClickListener {
                currentCategory = category
                for (i in 0 until categories.childCount) {
                    val child = categories.getChildAt(i) as Button
                    styleButton(child, child.text.toString() == currentCategory)
                }
                renderCatalog(catalogContainer)
            }
            val lp = LinearLayout.LayoutParams(-2, dp(42))
            lp.marginEnd = dp(8)
            categories.addView(b, lp)
        }
        page.addView(categories)
        addGap(page, 12)
        val shortcuts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("♡ المفضلة" to "favorites", "◷ أكمل المشاهدة" to "history", "↓ التنزيلات" to "downloads").forEach { pair ->
            val b = Button(this).apply { text = pair.first }
            styleButton(b)
            b.textSize = 11f
            b.setOnClickListener { showSaved(pair.second) }
            val lp = LinearLayout.LayoutParams(0, dp(42), 1f)
            lp.marginEnd = dp(5)
            shortcuts.addView(b, lp)
        }
        page.addView(shortcuts)
        addGap(page, 18)
        page.addView(text("كمل من وين وصلت", 20f, silver, true))
        addGap(page, 8)
        val lastTitle = prefs.getString("last_title", null)
        val lastItem = lastTitle?.let { itemByTitle(it) }
        if (lastItem != null) {
            val resume = Button(this).apply { text = "▶  متابعة ${lastItem.title}  •  ${formatPosition(prefs.getLong("position_${lastItem.title}", 0L))}" }
            styleButton(resume, true)
            resume.setOnClickListener { playItem(lastItem) }
            page.addView(resume, LinearLayout.LayoutParams(-1, dp(48)))
        } else {
            page.addView(text("راح تظهر هنا الأعمال اللي تبدي تشوفها", 12f, muted))
        }
        addGap(page, 18)
        page.addView(text("اختياراتنا إلك", 20f, silver, true))
        addGap(page, 10)

        catalogContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(catalogContainer)
        renderCatalog(catalogContainer)

        addGap(page, 18)
        page.addView(text("بيانات العناوين من TMDB • تشغيل الفيديو يحتاج مصدراً مرخّصاً", 11f, muted))
        scroll.addView(page)
        root.addView(scroll)
        setContentView(root)
    }

    private lateinit var catalogContainer: LinearLayout

    private fun renderCatalog(container: LinearLayout) {
        container.removeAllViews()
        val filtered = items.filter {
            (currentCategory == "الكل" || it.category == currentCategory) &&
            (searchTerm.isBlank() || it.title.contains(searchTerm, true) || it.description.contains(searchTerm, true))
        }
        if (filtered.isEmpty()) {
            container.addView(text("ما لقينا نتائج. جرّب كلمة ثانية.", 14f, muted))
            return
        }
        filtered.forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = rounded(panel, 18, Color.rgb(47,47,53))
            }
            val poster = FrameLayout(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.rgb(83,91,106), Color.rgb(31,35,43), Color.rgb(10,12,16))
                ).apply { cornerRadius = dp(12).toFloat() }
            }
            val posterText = text("▶", 27f, accent, true).apply { gravity = Gravity.CENTER }
            poster.addView(posterText, FrameLayout.LayoutParams(-1, -1))
            card.addView(poster, LinearLayout.LayoutParams(dp(88), dp(112)))

            val details = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, 0, 0)
            }
            details.addView(text(item.title, 16f, silver, true))
            addGap(details, 5)
            details.addView(text("${item.category}  •  ${item.year}", 12f, accent))
            addGap(details, 5)
            details.addView(text(item.description, 12f, muted))
            addGap(details, 10)
            val savedMs = prefs.getLong("position_${item.title}", 0L)
            if (savedMs > 0L) details.addView(text("آخر مشاهدة: ${formatPosition(savedMs)}", 11f, muted))
            val play = Button(this).apply { text = if (item.streamUrl.isBlank()) "قريباً" else if (savedMs > 0L) "متابعة المشاهدة" else "مشاهدة" }
            styleButton(play, true)
            play.isEnabled = item.streamUrl.isNotBlank()
            play.alpha = if (play.isEnabled) 1f else 0.5f
            play.setOnClickListener { playItem(item) }
            details.addView(play, LinearLayout.LayoutParams(-2, dp(42)))
            addGap(details, 4)
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val fav = Button(this).apply { text = if (isFavorite(item)) "♥ محفوظ" else "♡ مفضلة" }
            styleButton(fav)
            fav.textSize = 11f
            fav.setOnClickListener {
                toggleFavorite(item)
                fav.text = if (isFavorite(item)) "♥ محفوظ" else "♡ مفضلة"
                Toast.makeText(this@MainActivity, if (isFavorite(item)) "انضاف للمفضلة" else "انحذف من المفضلة", Toast.LENGTH_SHORT).show()
            }
            actions.addView(fav, LinearLayout.LayoutParams(-2, dp(38)))
            val download = Button(this).apply { text = "↓ تنزيل" }
            styleButton(download)
            download.textSize = 11f
            download.setOnClickListener { downloadItem(item) }
            val dl = LinearLayout.LayoutParams(-2, dp(38)); dl.marginStart = dp(5)
            actions.addView(download, dl)
            details.addView(actions)
            card.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(10)
            container.addView(card, lp)
        }
        val more = Button(this).apply { text = "تحميل المزيد من الأفلام والمسلسلات  ↓" }
        styleButton(more)
        more.setOnClickListener { loadPopularCatalog(reset = false) }
        container.addView(more, LinearLayout.LayoutParams(-1, dp(46)))
    }

    private fun scheduleRemoteSearch(query: String) {
        val requestId = ++searchRequestId
        networkHandler.postDelayed({
            if (requestId == searchRequestId && query.length >= 2) searchTmdb(query, requestId)
            else if (query.isBlank()) loadPopularCatalog(reset = true)
        }, 550)
    }

    private fun loadPopularCatalog(reset: Boolean) {
        if (reset) { moviePage = 1; tvPage = 1 }
        val mPage = moviePage
        val tPage = tvPage
        Thread {
            val movies = fetchTmdb("/movie/popular", mPage, "movie")
            val shows = fetchTmdb("/tv/popular", tPage, "tv")
            val trendingMovies = fetchTmdb("/trending/movie/week", 1, "movie")
            val trendingShows = fetchTmdb("/trending/tv/week", 1, "tv")
            val merged = (trendingMovies + trendingShows + movies + shows).distinctBy { it.category + "|" + it.title }
            runOnUiThread {
                if (reset) {
                    items.removeAll { it.isDemo.not() }
                }
                merged.forEach { incoming ->
                    val idx = items.indexOfFirst { it.title.equals(incoming.title, true) && it.category == incoming.category }
                    if (idx >= 0) items[idx] = incoming else items.add(incoming)
                }
                moviePage = mPage + 1; tvPage = tPage + 1
                renderCatalog(catalogContainer)
            }
        }.start()
    }

    private fun searchTmdb(query: String, requestId: Int) {
        Thread {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val movies = fetchTmdb("/search/movie?query=$encoded", 1, "movie")
            val shows = fetchTmdb("/search/tv?query=$encoded", 1, "tv")
            // Also search the Arabic title requested by the user. TMDB may not contain every regional title.
            val merged = (movies + shows).distinctBy { it.category + "|" + it.title }
            runOnUiThread {
                if (requestId != searchRequestId) return@runOnUiThread
                items.removeAll { it.isDemo.not() }
                merged.forEach { incoming -> items.add(incoming) }
                if (query.contains("أحلى") || query.contains("احلى") || query.contains("نصيب")) {
                    if (items.none { it.title.contains("أحلى نصيب", true) }) {
                        items.add(CinemaItem("أحلى نصيب", "مسلسلات", "2026", "ابحث عن توفر العمل ومصدر المشاهدة المرخّص؛ بياناته قد لا تكون مفهرسة في TMDB", "", false))
                    }
                }
                renderCatalog(catalogContainer)
            }
        }.start()
    }

    private fun fetchTmdb(path: String, page: Int, type: String): List<CinemaItem> {
        return try {
            val separator = if (path.contains("?")) "&" else "?"
            val url = URL("https://api.themoviedb.org/3$path${separator}api_key=$tmdbApiKey&language=ar-SA&page=$page")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 10000; readTimeout = 10000
            }
            try {
                if (connection.responseCode !in 200..299) return emptyList()
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                val results = JSONObject(body).optJSONArray("results") ?: return emptyList()
                val output = mutableListOf<CinemaItem>()
                for (i in 0 until results.length()) {
                    val obj = results.optJSONObject(i) ?: continue
                    val title = obj.optString(if (type == "movie") "title" else "name").ifBlank { obj.optString(if (type == "movie") "original_title" else "original_name") }
                    if (title.isBlank()) continue
                    val date = obj.optString(if (type == "movie") "release_date" else "first_air_date")
                    val year = date.take(4).ifBlank { "—" }
                    val overview = obj.optString("overview").ifBlank { "تفاصيل العمل متوفرة من TMDB" }
                    output.add(CinemaItem(title, if (type == "movie") "أفلام" else "مسلسلات", year, overview, "", false))
                }
                output
            } finally { connection.disconnect() }
        } catch (_: Exception) { emptyList() }
    }

    private fun playItem(item: CinemaItem) {
        if (item.streamUrl.isBlank()) {
            if (item.category == "مسلسلات") showEpisodes(item) else Toast.makeText(this, "هذا العنوان قريباً — أضف مصدراً مرخّصاً", Toast.LENGTH_LONG).show()
            return
        }
        releasePlayer()
        currentItem = item
        prefs.edit().putString("last_title", item.title).apply()
        prefs.edit().putStringSet("history", (prefs.getStringSet("history", emptySet()) ?: emptySet()) + item.title).apply()
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val back = Button(this).apply { text = "رجوع" }
        styleButton(back)
        back.setOnClickListener { showHome() }
        header.addView(back)
        val title = text(item.title, 17f, silver, true).apply {
            setPadding(dp(12), 0, 0, 0)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        column.addView(header)
        val playerFrame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
            setBackgroundColor(Color.BLACK)
        }
        playerFrame.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        // Glass control layer: translucent rounded controls over the video.
        val glassControls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val midControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val back10 = glassButton("↶ 10")
        back10.setOnClickListener { player?.let { it.seekTo((it.currentPosition - 10_000L).coerceAtLeast(0L)); showGestureHud("−10 ثواني") } }
        val playPause = glassButton("Ⅱ")
        playPause.textSize = 26f
        playPause.setOnClickListener { player?.let { if (it.isPlaying) { it.pause(); playPause.text = "▶" } else { it.play(); playPause.text = "Ⅱ" } } }
        val forward10 = glassButton("10 ↻")
        forward10.setOnClickListener { player?.let { it.seekTo((it.currentPosition + 10_000L).coerceAtMost(if (it.duration > 0) it.duration else Long.MAX_VALUE)); showGestureHud("+10 ثواني") } }
        listOf(back10, playPause, forward10).forEachIndexed { index, b ->
            val lp = LinearLayout.LayoutParams(if (index == 1) dp(70) else dp(62), dp(58))
            lp.marginStart = dp(7); lp.marginEnd = dp(7)
            midControls.addView(b, lp)
        }
        glassControls.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        glassControls.addView(midControls)
        glassControls.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        playerFrame.addView(glassControls, FrameLayout.LayoutParams(-1, -1))
        installPlayerGestures(playerFrame)
        val loader = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
        }
        val logoLoader = text("S", 42f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        loader.addView(logoLoader, LinearLayout.LayoutParams(-1, dp(60)))
        ObjectAnimator.ofFloat(logoLoader, View.ALPHA, 0.45f, 1f).apply { duration = 900; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(logoLoader, View.SCALE_X, 0.88f, 1.08f).apply { duration = 1300; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(logoLoader, View.SCALE_Y, 0.88f, 1.08f).apply { duration = 1300; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE; interpolator = AccelerateDecelerateInterpolator(); start() }
        val progress = ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        }
        loader.addView(progress, LinearLayout.LayoutParams(dp(34), dp(34)))
        loader.addView(text("S CINEMA", 11f, Color.WHITE, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, dp(30)))
        playerFrame.addView(loader, FrameLayout.LayoutParams(-1, -1))
        column.addView(playerFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        val playerActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val save = Button(this).apply { text = if (isFavorite(item)) "♥ بالمفضلة" else "♡ أضف للمفضلة" }
        styleButton(save)
        save.setOnClickListener { toggleFavorite(item); save.text = if (isFavorite(item)) "♥ بالمفضلة" else "♡ أضف للمفضلة" }
        playerActions.addView(save)
        val dlButton = Button(this).apply { text = "↓ تنزيل" }
        styleButton(dlButton)
        dlButton.setOnClickListener { downloadItem(item) }
        val dlp = LinearLayout.LayoutParams(-2, dp(44)); dlp.marginStart = dp(8)
        playerActions.addView(dlButton, dlp)
        column.addView(playerActions)
        val settingsButton = Button(this).apply { text = "⚙ إعدادات المقطع  •  الترجمة والجودة والتصفية" }
        styleButton(settingsButton)
        settingsButton.setOnClickListener { showClipSettings(item) }
        column.addView(settingsButton, LinearLayout.LayoutParams(-1, dp(44)))
        val note = text("اسحب يسار/يمين لتغيير الصوت أو السطوع. تُحفظ المتابعة محلياً على هذا الجهاز.", 11f, muted)
        column.addView(note)
        root.addView(column, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(item.streamUrl))
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    loader.visibility = if (playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE) View.VISIBLE else View.GONE
                }
                override fun onPlayerError(error: PlaybackException) {
                    loader.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "تعذّر تشغيل المصدر. تحقّق من الرابط والاتصال.", Toast.LENGTH_LONG).show()
                }
            })
            exo.prepare()
            val savedPosition = prefs.getLong("position_${item.title}", 0L)
            if (savedPosition > 0L) exo.seekTo(savedPosition)
            exo.setPlaybackSpeed(prefs.getFloat("playback_speed", 1f))
            exo.playWhenReady = true
        }
    }

    private fun glassButton(label: String): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(Color.argb(135, 30, 33, 40))
            cornerRadius = dp(30).toFloat()
            setStroke(dp(1), Color.argb(210, 225, 230, 240))
        }
        elevation = dp(5).toFloat()
        setPadding(dp(8), dp(4), dp(8), dp(4))
    }

    private fun showGestureHud(message: String) {
        val hud = gestureHud ?: return
        hud.text = message
        hud.visibility = View.VISIBLE
        hud.animate().cancel()
        hud.alpha = 1f
        hud.animate().alpha(0f).setStartDelay(700).setDuration(450).withEndAction { hud.visibility = View.GONE }.start()
    }

    private fun installPlayerGestures(frame: FrameLayout) {
        val hud = text("", 16f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(Color.argb(155, 35, 35, 39), 24, Color.argb(170, 235, 235, 240))
            setPadding(dp(22), dp(12), dp(22), dp(12))
            visibility = View.GONE
        }
        gestureHud = hud
        frame.addView(hud, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        frame.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gestureStartX = event.x; gestureStartY = event.y
                    val width = frame.width.coerceAtLeast(1)
                    gestureSide = if (event.x < width / 2f) 1 else 2
                    gestureStartValue = if (gestureSide == 1) {
                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                    } else window.attributes.screenBrightness.takeIf { it >= 0f } ?: 0.5f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = gestureStartY - event.y
                    if (kotlin.math.abs(dy) > dp(10)) {
                        val fraction = (gestureStartValue + dy / frame.height.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                        if (gestureSide == 1) {
                            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (fraction * max).toInt().coerceIn(0, max), 0)
                            showGestureHud("◖ الصوت ${ (fraction * 100).toInt() }%")
                        } else {
                            val attrs = window.attributes
                            attrs.screenBrightness = fraction.coerceIn(0.05f, 1f)
                            window.attributes = attrs
                            showGestureHud("☼ السطوع ${ (fraction * 100).toInt() }%")
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
    }

    private fun showSettings() {
        releasePlayer()
        val root = baseColumn()
        val page = baseColumn().apply { setPadding(dp(18), dp(18), dp(18), dp(24)) }
        val back = Button(this).apply { text = "رجوع" }; styleButton(back); back.setOnClickListener { showHome() }
        page.addView(back); addGap(page, 18)
        page.addView(text("إعدادات S CINEMA", 25f, Color.WHITE, true)); addGap(page, 14)
        page.addView(text("المظهر", 17f, silver, true)); addGap(page, 6)
        page.addView(text("واجهة سوداء وفضية • مؤثرات زجاجية • شاشة تحميل بيضاء", 13f, muted)); addGap(page, 16)
        val notifications = Switch(this).apply { text = "إشعارات التذكير (محلياً)"; setTextColor(silver); isChecked = prefs.getBoolean("notifications_enabled", true) }
        notifications.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("notifications_enabled", checked).apply() }
        page.addView(notifications); addGap(page, 12)
        val filtering = Switch(this).apply { text = "تخطّي المشاهد غير الملائمة"; setTextColor(silver); isChecked = prefs.getBoolean("filter_enabled", false) }
        filtering.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("filter_enabled", checked).apply(); Toast.makeText(this, if (checked) "التصفية مفعّلة للمشاهد ذات التوقيتات المتوفرة فقط" else "تم إيقاف التصفية", Toast.LENGTH_LONG).show() }
        page.addView(filtering); addGap(page, 10)
        page.addView(text("تنبيه: التصفية تحتاج توقيتات مشاهد موثوقة لكل عنوان. تفعيل المفتاح وحده لا يزيل مشاهد تلقائياً.", 12f, muted)); addGap(page, 16)
        page.addView(text("البيانات والحساب", 17f, silver, true)); addGap(page, 6)
        page.addView(text("المفضلة والتقدم محفوظان على الجهاز حالياً. استرجاعهما بعد حذف التطبيق يحتاج ربط Firebase أو Supabase بإعداداتك وقواعد أمان صحيحة.", 12f, muted))
        root.addView(page); setContentView(root)
    }

    private fun showClipSettings(item: CinemaItem) {
        val options = arrayOf("ترجمة (حسب مصدر الفيديو)", "الجودة (حسب مصدر الفيديو)", "سرعة التشغيل", "تخطّي المشاهد غير الملائمة")
        android.app.AlertDialog.Builder(this)
            .setTitle("إعدادات المقطع • ${item.title}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> Toast.makeText(this, "اختيار الترجمة يعتمد على المسارات المضمّنة في الفيديو.", Toast.LENGTH_LONG).show()
                    1 -> Toast.makeText(this, "اختيار الجودة يعتمد على توفر أكثر من مسار/دقة من المصدر.", Toast.LENGTH_LONG).show()
                    2 -> showSpeedDialog()
                    3 -> {
                        val enabled = !prefs.getBoolean("filter_enabled", false)
                        prefs.edit().putBoolean("filter_enabled", enabled).apply()
                        Toast.makeText(this, if (enabled) "التصفية مفعّلة للتوقيتات الموثوقة المتوفرة" else "تم إيقاف التصفية", Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("إغلاق", null).show()
    }

    private fun showSpeedDialog() {
        val speeds = arrayOf("0.75×", "1.0×", "1.25×", "1.5×", "2.0×")
        val values = floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 2f)
        android.app.AlertDialog.Builder(this).setTitle("سرعة التشغيل").setItems(speeds) { _, which ->
            player?.setPlaybackSpeed(values[which])
            prefs.edit().putFloat("playback_speed", values[which]).apply()
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun releasePlayer() {
        player?.let { exo ->
            currentItem?.let { item -> prefs.edit().putLong("position_${item.title}", exo.currentPosition).apply() }
            exo.release()
        }
        player = null
    }

    private fun itemByTitle(title: String): CinemaItem? = items.firstOrNull { it.title == title }

    private fun formatPosition(ms: Long): String {
        val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
        return String.format(java.util.Locale.US, "%02d:%02d", total / 60, total % 60)
    }

    private fun showProfile() {
        releasePlayer()
        val root = baseColumn()
        val page = baseColumn().apply { setPadding(dp(20), dp(20), dp(20), dp(24)) }
        val back = Button(this).apply { text = "رجوع" }; styleButton(back); back.setOnClickListener { showHome() }
        page.addView(back); addGap(page, 20)
        page.addView(text("حساب S CINEMA", 25f, Color.WHITE, true)); addGap(page, 8)
        page.addView(text("احفظ ملفك الشخصي على هذا الجهاز. المزامنة السحابية تحتاج إعداد مشروع خادم خاص بك.", 13f, muted)); addGap(page, 18)
        val name = EditText(this).apply { hint = "اسم العرض"; setText(prefs.getString("profile_name", "")); setTextColor(silver); setHintTextColor(muted); background = rounded(panel, 12, Color.DKGRAY); setPadding(dp(14), 0, dp(14), 0) }
        page.addView(name, LinearLayout.LayoutParams(-1, dp(50))); addGap(page, 10)
        val email = EditText(this).apply { hint = "البريد الإلكتروني (اختياري)"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; setText(prefs.getString("profile_email", "")); setTextColor(silver); setHintTextColor(muted); background = rounded(panel, 12, Color.DKGRAY); setPadding(dp(14), 0, dp(14), 0) }
        page.addView(email, LinearLayout.LayoutParams(-1, dp(50))); addGap(page, 14)
        val save = Button(this).apply { text = "حفظ الملف الشخصي" }; styleButton(save, true)
        save.setOnClickListener {
            prefs.edit().putString("profile_name", name.text.toString().trim()).putString("profile_email", email.text.toString().trim()).apply()
            Toast.makeText(this, "انحفظ الملف الشخصي على هذا الجهاز", Toast.LENGTH_LONG).show()
        }
        page.addView(save, LinearLayout.LayoutParams(-1, dp(48))); addGap(page, 18)
        page.addView(text("تنبيه: هذا ليس تسجيل دخول سحابياً بعد. حتى ترجع بياناتك بعد حذف التطبيق، اربط المشروع بـ Firebase أو Supabase وأضف إعدادات المشروع وقواعد الأمان.", 12f, muted))
        root.addView(page); setContentView(root)
    }

    private fun isFavorite(item: CinemaItem): Boolean =
        (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).contains(item.title)

    private fun toggleFavorite(item: CinemaItem) {
        val set = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        if (!set.add(item.title)) set.remove(item.title)
        prefs.edit().putStringSet("favorites", set).apply()
    }

    private fun downloadItem(item: CinemaItem) {
        if (item.streamUrl.isBlank()) {
            Toast.makeText(this, "ماكو رابط تنزيل لهذا العنوان بعد. أضف رابطاً مرخّصاً مباشراً.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val request = DownloadManager.Request(Uri.parse(item.streamUrl))
                .setTitle("S CINEMA • ${item.title}")
                .setDescription("تنزيل المحتوى")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "SCinema_${item.title.replace(Regex("[^A-Za-z0-9_-]"), "_")}.mp4")
                .setAllowedOverMetered(true).setAllowedOverRoaming(false)
            val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            val ids = (prefs.getStringSet("downloads", emptySet()) ?: emptySet()).toMutableSet()
            ids.add(item.title)
            prefs.edit().putStringSet("downloads", ids).apply()
            Toast.makeText(this, "بدأ التنزيل — تابع الإشعار", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر بدء التنزيل لهذا المصدر", Toast.LENGTH_LONG).show()
        }
    }

    private fun showSaved(mode: String) {
        releasePlayer()
        val root = baseColumn()
        val page = baseColumn().apply { setPadding(dp(18), dp(18), dp(18), dp(24)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = Button(this).apply { text = "رجوع" }; styleButton(back); back.setOnClickListener { showHome() }
        header.addView(back)
        header.addView(text(when(mode) { "favorites" -> "المفضلة"; "history" -> "أكمل المشاهدة"; else -> "التنزيلات" }, 21f, silver, true).apply { setPadding(dp(12),0,0,0) })
        page.addView(header); addGap(page, 18)
        val titles = when(mode) {
            "favorites" -> prefs.getStringSet("favorites", emptySet()) ?: emptySet()
            "history" -> prefs.getStringSet("history", emptySet()) ?: emptySet()
            else -> prefs.getStringSet("downloads", emptySet()) ?: emptySet()
        }
        val scroll = ScrollView(this); val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.toList().reversed().forEach { title -> itemByTitle(title)?.let { item ->
            val b = Button(this).apply { text = "${item.title}  •  ${item.category}\n${if (mode == "history") "متابعة من آخر موضع" else if (mode == "downloads") "تم طلب التنزيل" else "فتح العنوان"}"; gravity = Gravity.START or Gravity.CENTER_VERTICAL }
            styleButton(b); b.setOnClickListener { if (mode == "downloads") downloadItem(item) else playItem(item) }
            val lp = LinearLayout.LayoutParams(-1, dp(64)); lp.bottomMargin = dp(8); list.addView(b, lp)
        } }
        if (list.childCount == 0) list.addView(text("القائمة فارغة حالياً.", 14f, muted))
        scroll.addView(list); page.addView(scroll); root.addView(page); setContentView(root)
    }

    private fun showEpisodes(series: CinemaItem) {
        releasePlayer()
        val root = baseColumn(); val page = baseColumn().apply { setPadding(dp(18), dp(18), dp(18), dp(24)) }
        val back = Button(this).apply { text = "رجوع" }; styleButton(back); back.setOnClickListener { showHome() }; page.addView(back)
        addGap(page, 14); page.addView(text(series.title, 25f, Color.WHITE, true))
        page.addView(text("الموسم الأول • جدول تجريبي للنشر اليومي", 13f, muted)); addGap(page, 8)
        page.addView(text("موعد العرض المقترح: يومياً الساعة 8:00 مساءً بتوقيت العراق. اربط جدول النشر بمصدر المحتوى قبل الإطلاق.", 12f, muted)); addGap(page, 18)
        val nextRelease = nextEightPmIraq()
        val countdown = text("الحلقة القادمة • ${countdownText(nextRelease)}", 15f, Color.WHITE, true)
        countdown.background = rounded(panel, 14, Color.rgb(70,70,76)); countdown.setPadding(dp(14), dp(12), dp(14), dp(12))
        page.addView(countdown, LinearLayout.LayoutParams(-1, -2)); addGap(page, 14)
        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                if (countdown.isAttachedToWindow) {
                    countdown.text = "الحلقة القادمة • ${countdownText(nextEightPmIraq())}"
                    Handler(Looper.getMainLooper()).postDelayed(this, 60_000L)
                }
            }
        })
        for (ep in 1..10) {
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12)); background = rounded(panel, 16, Color.rgb(48,48,54)) }
            card.addView(text("الحلقة $ep", 17f, silver, true))
            card.addView(text(if (ep == 1 && series.streamUrl.isNotBlank()) "متوفرة للمشاهدة" else "قريباً • ${if (ep == 10) "الحلقة التالية" else "الحلقة غير متاحة بعد"}", 12f, muted))
            if (ep == 1 && series.streamUrl.isNotBlank()) {
                val watch = Button(this).apply { text = "مشاهدة الحلقة" }; styleButton(watch, true); watch.setOnClickListener { playItem(series) }
                card.addView(watch)
            }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); page.addView(card, lp)
        }
        val scroll = ScrollView(this); scroll.addView(page); root.addView(scroll); setContentView(root)
    }

    private fun nextEightPmIraq(): Long {
        val zone = java.time.ZoneId.of("Asia/Baghdad")
        val now = java.time.ZonedDateTime.now(zone)
        var next = now.toLocalDate().atTime(20, 0).atZone(zone)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return next.toInstant().toEpochMilli()
    }

    private fun countdownText(targetMs: Long): String {
        val seconds = ((targetMs - System.currentTimeMillis()).coerceAtLeast(0L) / 1000L)
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60
        return String.format(java.util.Locale.US, "%02d:%02d:%02d", hours, minutes, secs)
    }

    override fun onStop() {
        super.onStop()
        player?.let { exo ->
            currentItem?.let { item -> prefs.edit().putLong("position_${item.title}", exo.currentPosition).apply() }
            exo.pause()
        }
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }
}
